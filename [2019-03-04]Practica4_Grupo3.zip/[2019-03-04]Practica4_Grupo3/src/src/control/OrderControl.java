package control;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

import org.basex.core.BaseXException;
import org.basex.core.cmd.XQuery;
import org.basex.query.QueryException;
import org.basex.query.QueryProcessor;
import org.basex.query.iter.Iter;
import org.basex.query.value.item.Item;

import entities.Book;
import entities.Order;

public class OrderControl {

	public static final String ORDERID_FIELD = "$i/orderID";
	public static final String CLIENTDNI_FIELD ="$i/clientDNI";
	
	public ArrayList<Order> selectOrder(String field, String value) {
	    ArrayList<Order> orders= new ArrayList<Order>();
		 try {
	    String queryArray = "for $i in doc('BookShop/orders.xml')//orders/order "
	    				  + "where " + field + " = '" + value + "' "
		+ "let $array := array{(data($i/orderID), data($i/clientDNI), data($i/date))}"
		+ "return $array";
	    QueryProcessor proc = new QueryProcessor(queryArray, ContextContainer.context);
	    //Conseguir iterador para iterar por cada resultado de la query
	    Iter itr = proc.iter();
	    Item item;
	    while((item = itr.next())!= null) {
	    	Order order = new Order();
	    	loadOrder(order, item);
	    	orders.add(order);
	    }
	    // Close the database context
	    proc.close();
		 }catch(QueryException e) {
			 e.printStackTrace();
		 }finally {
		 }
		return orders;
	}
	
	public void insertOrder(Order order) {
		 try {
			 SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			 String date = sdf.format(order.getDate());
	    String queryInsert = "let $up := <order>"+ 
	    		"<orderID>" + order.getOrderId() + "</orderID>" +  
	    		" <clientDNI>"+ order.getClientDNI() + "</clientDNI>" + 
	    		"<date>" + date + "</date>" + 
	    		" </order> " +
	    		"return insert node $up as last into doc('BookShop/orders.xml')//orders ";
	    	new XQuery(queryInsert).execute(ContextContainer.context);
	    	insertIsbns(order);
	    	insertCodes(order);
	    	insertQuantities(order);
		 }catch(BaseXException e){
			 e.printStackTrace();
		 }finally {
		 }
	}
	
	public void deleteOrder(int orderID) {
		try {
			String queryDelete = "for $i in doc('BookShop/orders.xml')//orders/order where $i/orderID = " + orderID
					+ " return delete node $i";
		new XQuery(queryDelete).execute(ContextContainer.context);
		}catch(BaseXException e) {
			e.printStackTrace();
		}
	}
	
	private void loadOrder(Order order, Item item) {
		try {
		Object[] obj = (Object[])item.toJava();
	    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    	//Convertir el array de objetos a un array de strings
    	String[] stringArray = Arrays.copyOf(obj, obj.length, String[].class);
    	int orderID = Integer.parseInt(stringArray[0]);
    	order.setOrderId(orderID);
    	order.setClientDNI(stringArray[1]);
    	String date = stringArray[2];
    	order.setDate(sdf.parse(date));
    	System.out.println(orderID);
    	order.setIsbn(getIsbns(orderID));
    	order.setWarehouseCodes(getCodes(orderID));
    	order.setQuantity(getQuantities(orderID));
		}catch(ParseException e) {
			e.printStackTrace();
		}catch(QueryException f) {
			
		}
	}
	
	public ArrayList<Order> selectAllOrders(){
	    ArrayList<Order> orders= new ArrayList<Order>();
		 try {
	    String queryArray = "for $i in doc('BookShop/orders.xml')//orders/order "
		+ "let $array := array{(data($i/orderID), data($i/clientDNI), data($i/date))}"
		+ "return $array";
	    QueryProcessor proc = new QueryProcessor(queryArray, ContextContainer.context);
	    //Conseguir iterador para iterar por cada resultado de la query
	    Iter itr = proc.iter();
	    Item item;
	    while((item = itr.next())!= null) {
	    	Order order = new Order();
	    	loadOrder(order, item);
	    	orders.add(order);
	    }
	    // Close the database context
	    proc.close();
		 }catch(QueryException e) {
			 e.printStackTrace();
		 }finally {
		 }
		return orders;
	}
	
	private void insertIsbns(Order order) {
		try {
			String queryIsbns = "for $i in doc('BookShop/orders.xml')//orders/order where $i/orderID = " + order.getOrderId() + " " +
					"let $up := " + 
					"<isbns></isbns>  " + 
					"return insert node $up as last into doc('BookShop/orders.xml')/$i";
			new XQuery(queryIsbns).execute(ContextContainer.context);
			Iterator itr = order.getIsbn().iterator();
			while(itr.hasNext()) {
				String queryIsbn = "for $i in doc('BookShop/orders.xml')//orders/order where $i/orderID = " + order.getOrderId() + " " +
						"let $up := " + 
						"<isbn> " + (String)itr.next() + "</isbn> " + 
						"return insert node $up as last into doc('BookShop/orders.xml')/$i/isbns";
				new XQuery(queryIsbn).execute(ContextContainer.context);
			}
		}catch(BaseXException e) {
			
		}
	}
	
	private void insertCodes(Order order) {
		try {
			String queryCodes = "for $i in doc('BookShop/orders.xml')//orders/order where $i/orderID = " + order.getOrderId() + " " +
					"let $up := " + 
					"<codWarehouses></codWarehouses>  " + 
					"return insert node $up as last into doc('DBExample')/$i";
			new XQuery(queryCodes).execute(ContextContainer.context);
			Iterator itr = order.getWarehouseCodes().iterator();
			while(itr.hasNext()) {
				String queryCode = "for $i in doc('BookShop/orders.xml')//orders/order where $i/orderID = " + order.getOrderId() + " " +
						"let $up := " + 
						"<codWarehouse>" + itr.next() + "</codWarehouse> " + 
						"return insert node $up as last into doc('BookShop/orders.xml')/$i/codWarehouses";
				new XQuery(queryCode).execute(ContextContainer.context);
			}
		}catch(BaseXException e) {
			
		}
	}
	
	private void insertQuantities(Order order) {
		try {
			String queryQuantities = "for $i in doc('BookShop/orders.xml')//orders/order where $i/orderID = " + order.getOrderId() + " " +
					"let $up := " + 
					"<quantities></quantities>  " + 
					"return insert node $up as last into doc('BookShop/orders.xml')/$i";
			new XQuery(queryQuantities).execute(ContextContainer.context);
			Iterator itr = order.getQuantity().iterator();
			while(itr.hasNext()) {
				String queryQuantity = "for $i in doc('BookShop/orders.xml')//orders/order where $i/orderID = " + order.getOrderId() + " " +
						"let $up := " + 
						"<quantity>" + itr.next() + "</quantity> " + 
						"return insert node $up as last into doc('BookShop/orders.xml')/$i/quantities";
				new XQuery(queryQuantity).execute(ContextContainer.context);
			}
		}catch(BaseXException e) {
			
		}
	}
	
	private ArrayList<String> getIsbns(int orderid) {
		System.out.println(orderid);
		String queryIsbns = "for $i in doc('BookShop/orders.xml')//orders/order where $i/orderID = " + orderid
				+ " for $x in $i/isbns/isbn return data($x)";
		ArrayList<String> isbns = new ArrayList<String>();
		try {
			QueryProcessor proc = new QueryProcessor(queryIsbns, ContextContainer.context);
		    //Conseguir iterador para iterar por cada resultado de la query
		    Iter itr = proc.iter();
		    Item item;
		    while((item = itr.next())!=null) {
		    	System.out.println(item.toJava());
		    	isbns.add((String)item.toJava());
		    }
		}catch(QueryException e) {
			
		}
		return isbns;
	}
	
	private ArrayList<Integer> getCodes(int orderid) {
		String queryCodes = "for $i in doc('BookShop/orders.xml')//orders/order where $i/orderID = " + orderid 
				+ " for $x in $i/codWarehouses/codWarehouse return data($x)";
		ArrayList<Integer> codes = new ArrayList<Integer>();
		try {
			QueryProcessor proc = new QueryProcessor(queryCodes, ContextContainer.context);
		    //Conseguir iterador para iterar por cada resultado de la query
		    Iter itr = proc.iter();
		    Item item;
		    while((item = itr.next())!=null) {
		    	codes.add(Integer.parseInt((String)item.toJava()));
		    }
		}catch(QueryException e) {
			
		}
		return codes;
	}
	
	private ArrayList<Integer> getQuantities(int orderid){
		String queryQuantities = "for $i in doc('BookShop/orders.xml')//orders/order where $i/orderID = " + orderid 
				+ " for $x in $i/quantities/quantity return data($x)";
		ArrayList<Integer> quantities = new ArrayList<Integer>();
		try {
			QueryProcessor proc = new QueryProcessor(queryQuantities, ContextContainer.context);
		    //Conseguir iterador para iterar por cada resultado de la query
		    Iter itr = proc.iter();
		    Item item;
		    while((item = itr.next())!=null) {
		    	quantities.add(Integer.parseInt((String)item.toJava()));
		    }
		}catch(QueryException e) {
			
		}
		return quantities;
	}
}
