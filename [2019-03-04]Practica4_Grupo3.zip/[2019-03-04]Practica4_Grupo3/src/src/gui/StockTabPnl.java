package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;

import entities.Book;
import entities.Client;
import entities.Stock;
import control.StockControl;

public class StockTabPnl extends TabPnl {

	ArrayList<Stock> stocks = new ArrayList<Stock>();
	private StockControl sc = new StockControl();
	
	public StockTabPnl() {
		super();
		initStock();
	}

	
	public void initStock() {
		stocks = sc.selectAllStocks();
		comboBox.setModel(new DefaultComboBoxModel(new String[] { "ISBN", "WAREHOUSECODE", "gtQUANTITY", "ltQUANTITY" }));
		table.setModel(new StockTblModel(stocks));
		scrollPane.setViewportView(table);
	}


	@Override
	public void deleteAction() {
		int[] rows = table.getSelectedRows();
		for(int i = 0; i< rows.length; ++i) {
			String isbn = stocks.get(rows[i]).getIsbn();
			int code = stocks.get(rows[i]).getCodWarehouse();
			sc.deleteStock(isbn, code);
		}
		delete(rows, stocks);
		
	}


	@Override
	public void textFieldSearchAction() {
		String value = textField.getText();
		if(value.equals("")) {
			stocks = sc.selectAllStocks();
		}else {
			switch((String)comboBox.getSelectedItem()) {
			case "ISBN": stocks = sc.selectStock(StockControl.ISBN_FIELD, value);
				break;
			case "WAREHOUSECODE": stocks = sc.selectStock(StockControl.CODE_FIELD, value);
				break;
			case "gtQUANTITY": 
				try{
				int quantity = Integer.parseInt(value); 
				stocks = sc.selectStockQuantity(StockControl.GTQUANTITY_FIELD, quantity);
				}catch(NumberFormatException e) {
				
				}
				break;
			case "ltQUANTITY":
				try{
				int quantity = Integer.parseInt(value); 
				stocks = sc.selectStockQuantity(StockControl.LTQUANTITY_FIELD, quantity);
				}catch(NumberFormatException e) {
				
				}
				break;
			}
		}
		((StockTblModel)table.getModel()).setStocks(stocks);
		((StockTblModel)table.getModel()).fireTableDataChanged();
		table.clearSelection();
	}


	@Override
	public void addAction() {
		StockDialog add = new StockDialog();
		add.setVisible(true);
		((StockTblModel)table.getModel()).fireTableDataChanged();
		
	}


	@Override
	public void editAction() {
		int row = table.getSelectedRow();
		Stock stock = new Stock();
		if(row>=0) {
			stock = ((StockTblModel)table.getModel()).getStock(row);
			QuantityDialog edit = new QuantityDialog(stock);
			edit.setVisible(true);
			sc.updateStock(stock);
			((StockTblModel)table.getModel()).fireTableDataChanged();
		}
	}

}
