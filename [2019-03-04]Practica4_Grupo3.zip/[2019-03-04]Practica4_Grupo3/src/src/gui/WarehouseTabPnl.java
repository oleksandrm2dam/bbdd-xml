package gui;

import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;

import control.WarehouseControl;
import entities.Stock;
import entities.Warehouse;

public class WarehouseTabPnl extends TabPnl{

	private ArrayList<Warehouse> warehouses = new ArrayList<Warehouse>();
	private WarehouseControl wc = new WarehouseControl();
	
	public WarehouseTabPnl() {
		super();
		initWarehouse();
	}
	
	@Override
	public void deleteAction() {
		int[] rows = table.getSelectedRows();
		for(int i = 0; i< rows.length; ++i) {
			int code = warehouses.get(rows[i]).getCodWarehouse();
			wc.deleteWarehouse(String.valueOf(code));
		}
		delete(rows, warehouses);
	}

	@Override
	public void textFieldSearchAction() {
		String value = textField.getText();
		if(value.equals("")) {
			warehouses = wc.selectAllWarehouses();
		}else {
			switch((String)comboBox.getSelectedItem()) {
			case "CODE": warehouses = wc.selectWarehouse(WarehouseControl.CODE_FIELD, value);
				break;
			case "NAME": warehouses = wc.selectWarehouse(WarehouseControl.NAME_FIELD, value);
				break;
			case "POPULATION": warehouses = wc.selectWarehouse(WarehouseControl.POPULATION_FIELD, value);
				break;
			}
		}
		((WarehouseTblModel)table.getModel()).setWarehouses(warehouses);
		((WarehouseTblModel)table.getModel()).fireTableDataChanged();
		table.clearSelection();
	}

	@Override
	public void addAction() {
		WarehouseDialog add = new WarehouseDialog();
		add.setVisible(true);
		((WarehouseTblModel)table.getModel()).fireTableDataChanged();
		
	}

	@Override
	public void editAction() {
		int row = table.getSelectedRow();
		Warehouse warehouse = new Warehouse();
		if(row>=0) {
			warehouse = ((WarehouseTblModel)table.getModel()).getWarehouse(row);
			WarehouseDialog edit = new WarehouseDialog(warehouse);
			edit.setVisible(true);
			((WarehouseTblModel)table.getModel()).fireTableDataChanged();
		}
	}


	public void initWarehouse(){
		warehouses = wc.selectAllWarehouses();
		comboBox.setModel(new DefaultComboBoxModel(new String[] { "CODE", "NAME", "POPULATION"}));
		table.setModel(new WarehouseTblModel(warehouses));
		scrollPane.setViewportView(table);
	}
}
