package gui;

import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;

import control.ClientControl;
import entities.Book;
import entities.Client;

public class ClientTabPnl extends TabPnl {
	
	private ArrayList<Client> clients = new ArrayList<Client>();
	private ClientControl cc = new ClientControl();
	
	public ClientTabPnl() {
		super();
		initClient();
	}

	@Override
	public void deleteAction() {
		int[] rows = table.getSelectedRows();
		for(int i = 0; i< rows.length; ++i) {
			String dni = clients.get(rows[i]).getDni();
			cc.deleteClient(dni);
		}
		delete(rows, clients);
	}

	@Override
	public void textFieldSearchAction() {
		String value = textField.getText();
		if(value.equals("")) {
			clients = cc.selectAllClients();
		}else {
			switch((String)comboBox.getSelectedItem()) {
			case "DNI": clients = cc.selectClient(ClientControl.DNI_FIELD, value);
				break;
			case "NAME": clients = cc.selectClient(ClientControl.NAME_FIELD, value);
				break;
			case "SURNAMES": clients = cc.selectClient(ClientControl.SURNAMES_FIELD, value);
				break;
			}
		}
		((ClientTblModel)table.getModel()).setClients(clients);
		((ClientTblModel)table.getModel()).fireTableDataChanged();
		table.clearSelection();
	}

	@Override
	public void addAction() {
		ClientDialog add = new ClientDialog();
		add.setVisible(true);
		((ClientTblModel)table.getModel()).fireTableDataChanged();
		
	}

	@Override
	public void editAction() {
		int row = table.getSelectedRow();
		Client client= new Client();
		if(row>=0) {
			client = ((ClientTblModel)table.getModel()).getClient(row);
			ClientDialog editPnl = new ClientDialog(client);
			editPnl.setVisible(true);
			((ClientTblModel)table.getModel()).fireTableDataChanged();
		}
	}
	
	public void initClient() {
		clients = cc.selectAllClients();
		comboBox.setModel(new DefaultComboBoxModel(new String[] { "DNI", "NAME", "SURNAMES"}));
		table.setModel(new ClientTblModel(clients));
		scrollPane.setViewportView(table);
	}

	
}
