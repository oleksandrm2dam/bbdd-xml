package control;

import org.basex.core.Context;

public class ContextContainer {

	public static Context context;
	
	public void createContext() {
		context = new Context();
	}
}
