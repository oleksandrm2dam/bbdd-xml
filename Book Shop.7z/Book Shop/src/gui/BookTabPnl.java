package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import javax.swing.DefaultComboBoxModel;

import control.BookControl;
import entities.Book;
import entities.Warehouse;

public class BookTabPnl extends TabPnl {

	ArrayList<Book> books = new ArrayList<Book>();
	BookControl bc = new BookControl();
	
	public BookTabPnl() {
		super();
		initBooks();
	}
	@Override
	public void deleteAction() {
		int[] rows = table.getSelectedRows();
		for(int i = 0; i< rows.length; ++i) {
			String isbn = books.get(rows[i]).getIsbn();
			bc.deleteBook(isbn);
		}
		delete(rows, books);
	}
	@Override
	public void textFieldSearchAction() {
		String value = textField.getText();
		System.out.println(bc.selectBookISBN(value));
		books= new ArrayList<Book>();
		Book book = new Book();
		if(value.equals("")) {
			books = bc.selectAllBooks();
		}else {
			switch((String)comboBox.getSelectedItem()) {
			case "ISBN": books = bc.selectBook(BookControl.ISBN_FIELD, value);
				break;
			case "TITLE": books = bc.selectBook(BookControl.TITLE_FIELD, value);
				break;
			case "AUTHOR": books = bc.selectBook(BookControl.AUTHOR_FIELD, value);
				break;
			}
		}
		Iterator itr = books.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next().toString());
		}
		((BookTblModel)table.getModel()).setBooks(books);
		((BookTblModel)table.getModel()).fireTableDataChanged();
		//table.repaint();
		table.clearSelection();
	}
	@Override
	public void addAction() {
		BookDialog addPnl = new BookDialog();
		addPnl.setVisible(true);
		((BookTblModel)table.getModel()).fireTableDataChanged();
	}
	@Override
	public void editAction() {
		int row = table.getSelectedRow();
		Book book = new Book();
		if(row>=0) {
			book = ((BookTblModel)table.getModel()).getBook(row);
			BookDialog addPnl = new BookDialog(book);
			addPnl.setVisible(true);
			((BookTblModel)table.getModel()).fireTableDataChanged();
		}
	}
	
	public void initBooks() {
		books = new ArrayList<Book>();
		books = bc.selectAllBooks();
		comboBox.setModel(new DefaultComboBoxModel(new String[] { "ISBN", "AUTHOR", "TITLE" }));
		table.setModel(new BookTblModel(books));
		scrollPane.setViewportView(table);
	}

}
