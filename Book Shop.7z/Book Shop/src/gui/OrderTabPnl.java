package gui;

import java.util.ArrayList;
import java.util.Date;

import javax.swing.DefaultComboBoxModel;

import control.OrderControl;
import control.StockControl;
import entities.Book;
import entities.Order;
import entities.Stock;

public class OrderTabPnl extends TabPnl {

	private ArrayList<Order> orders = new ArrayList<Order>();
	private OrderControl oc = new OrderControl();
	private StockControl sc = new StockControl();
	
	public OrderTabPnl() {
		super();
		initOrder();
	}
	
	@Override
	public void deleteAction() {
		int[] rows = table.getSelectedRows();
		for(int i = 0; i< rows.length; ++i) {
			Order order = orders.get(rows[i]);
			int orderid = order.getOrderId();
			updateStocks(order);
			oc.deleteOrder(orderid);
		}
		delete(rows, orders);
	}

	@Override
	public void textFieldSearchAction() {
		String value = textField.getText();
		if(value.equals("")) {
			orders = oc.selectAllOrders();
		}else {
			switch((String)comboBox.getSelectedItem()) {
			case "ORDERID": orders = oc.selectOrder(OrderControl.ORDERID_FIELD, value);
				break;
			case "CLIENTDNI": orders = oc.selectOrder(OrderControl.CLIENTDNI_FIELD, value);
				break;
			}
		}
		((OrderTblModel)table.getModel()).setOrders(orders);
		((OrderTblModel)table.getModel()).fireTableDataChanged();
		table.clearSelection();
	}

	@Override
	public void addAction() {
		OrderDialog add = new OrderDialog();
		add.setVisible(true);
	}

	@Override
	public void editAction() {
		int row = table.getSelectedRow();
		Order order = new Order();
		if(row>=0) {
			order = ((OrderTblModel)table.getModel()).getOrder(row);
			OrderDialog addPnl = new OrderDialog(order);
			addPnl.setVisible(true);
		}

	}
	
	
	public void initOrder(){
		orders = oc.selectAllOrders();
		comboBox.setModel(new DefaultComboBoxModel(new String[] { "ORDERID", "CLIENTDNI"}));
		table.setModel(new OrderTblModel(orders));
		scrollPane.setViewportView(table);
	}
	
	private void updateStocks(Order order) {
		String isbn= "";
		int code = 0;
		int quantity = 0;
		Stock stock = new Stock();
		for(int i=0; i<order.getIsbn().size(); ++i) {
			isbn = order.getIsbn().get(i);
			code = order.getWarehouseCodes().get(i);
			quantity = order.getQuantity().get(i);
			stock = sc.selectStockIsbnCod(isbn, code);
			stock.setQuantity(stock.getQuantity() + quantity);
			if(stock.getQuantity()<0) {
				stock.setQuantity(0);
			}
			sc.updateStock(stock);
			
		}
	}



}
