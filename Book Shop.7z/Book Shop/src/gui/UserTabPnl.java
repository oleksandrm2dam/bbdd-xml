package gui;

import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;

import control.UserControl;
import entities.User;

public class UserTabPnl extends TabPnl {

	private ArrayList<User> users = new ArrayList<User>();
	private UserControl uc = new UserControl();
	
	public UserTabPnl() {
		super();
		initUser();
	}
	@Override
	public void deleteAction() {
		int[] rows = table.getSelectedRows();
		for(int i = 0; i< rows.length; ++i) {
			String name = users.get(rows[i]).getName();
			uc.deleteUser(name);
		}
		delete(rows, users);
	}

	@Override
	public void textFieldSearchAction() {
		String value = textField.getText();
		if(value.equals("")) {
			users = uc.selectAllUsers();
		}else {
			switch((String)comboBox.getSelectedItem()) {
			case "NAME": users = uc.selectUser(UserControl.NAME_FIELD, value);
				break;
			case "PROFILE": users = uc.selectUser(UserControl.PROFILE_FIELD, value);
				break;
			}
		}
		((UserTblModel)table.getModel()).setUsers(users);
		((UserTblModel)table.getModel()).fireTableDataChanged();
		table.clearSelection();
	}

	@Override
	public void addAction() {
		UserDialog add = new UserDialog();
		add.setVisible(true);
		
	}

	@Override
	public void editAction() {
		int row = table.getSelectedRow();
		User user = new User();
		if(row>=0) {
			user = ((UserTblModel)table.getModel()).getUser(row);
			UserDialog edit = new UserDialog(user);
			((UserTblModel)table.getModel()).fireTableDataChanged();
			edit.setVisible(true);
		}

	}

	public void initUser() {
		users = uc.selectAllUsers();
		comboBox.setModel(new DefaultComboBoxModel(new String[] { "NAME", "PROFILE" }));
		table.setModel(new UserTblModel());
		((UserTblModel)table.getModel()).setUsers(users);
		scrollPane.setViewportView(table);
	}

}
